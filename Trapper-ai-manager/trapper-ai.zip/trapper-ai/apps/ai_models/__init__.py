default_app_config = "apps.ai_models.apps.AIModelsConfig"
